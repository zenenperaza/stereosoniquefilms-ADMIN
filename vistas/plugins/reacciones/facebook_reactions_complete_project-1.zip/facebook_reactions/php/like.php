<?php
// Here you can add code to save the values in the database
// Getting the reaction from Ajax and printing
echo "Reaction :)";
?>