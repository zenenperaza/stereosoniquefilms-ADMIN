<?php
// Here you can add code to save the values in the database
echo "Undo Like";
?>